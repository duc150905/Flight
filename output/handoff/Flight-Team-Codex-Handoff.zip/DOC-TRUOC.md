# Flight team handoff — 02/11/2026

Đọc TEAM-CODEX-HANDOFF.md, rồi CHECKOUT-NEXT-WALKTHROUGH.md, LOCALIZATION.md và CHECKOUT-DEMO.md. Phần snapshot cũ trong handoff đã được cập nhật bằng ghi chú đầu file. Khi làm tiếp, pull main mới nhất; không tự coi các task còn lại là lệnh triển khai. PDF UI ở reference/flight.pdf.
